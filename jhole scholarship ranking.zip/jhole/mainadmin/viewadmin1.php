<?php 
include('../function.php');

if (!ismainAdmin()) {
  $_SESSION['msg'] = "You must log in first";
  header('location: ../register.php');
}

if (isset($_GET['logout'])) {
  session_destroy();
  unset($_SESSION['user']);
  header("location: ../index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin Dashboard</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="robots" content="all,follow">
  <!-- Bootstrap CSS-->
  <link rel="stylesheet" href="../distribution/vendor/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome CSS-->
  <link rel="stylesheet" href="../distribution/vendor/font-awesome/css/font-awesome.min.css">
  <!-- Fontastic Custom icon font-->
  <link rel="stylesheet" href="../distribution/css/fontastic.css">
  <!-- Google fonts - Poppins -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
  <!-- theme stylesheet-->
  <link rel="stylesheet" href="../distribution/css/style.default.css" id="theme-stylesheet">
  <!-- Custom stylesheet - for your changes-->
  <link rel="stylesheet" href="../distribution/css/custom.css">
  <!-- Favicon-->
  <link rel="shortcut icon" href="../img/favicon.ico">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
      </head>
      <body>
        <div class="page">
          <!-- Main Navbar-->
          <header class="header">
            <nav class="navbar">
              <!-- Search Box-->
              <div class="search-box">
                <button class="dismiss"><i class="icon-close"></i></button>

              </div>
              <div class="container-fluid">
                <div class="navbar-holder d-flex align-items-center justify-content-between">
                  <!-- Navbar Header-->
                  <div class="navbar-header">
                    <!-- Navbar Brand --><a href="database.php" class="navbar-brand d-none d-sm-inline-block">
                      <div class="brand-text d-none d-lg-inline-block"><span>Admin </span><strong>Dashboard</strong></div>
                      <div class="brand-text d-none d-sm-inline-block d-lg-none"><strong>AD</strong></div></a>
                      <!-- Toggle Button--><a id="toggle-btn" href="#" class="menu-btn active"><span></span><span></span><span></span></a>
                    </div>
                    <!-- Navbar Menu -->
                    <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">


                      <!-- Logout    -->
                      <li class="nav-item"><a href="database.php?logout='1'" class="nav-link logout"> <span class="d-none d-sm-inline">Logout</span><i class="fa fa-sign-out"></i></a></li>
                    </ul>
                  </div>
                </div>
              </nav>
            </header>
            <div class="page-content d-flex align-items-stretch"> 
              <!-- Side Navbar -->
              <nav class="side-navbar">
                <!-- Sidebar Header-->
                <div class="sidebar-header d-flex align-items-center">
                  <div class="avatar"><img src="../distribution/img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
                  <div class="title">
                    <h1 class="h4"><?php $name=$_SESSION['username'];echo "$name";?></h1>
                    
                  </div>
                </div>
                <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
                <ul class="list-unstyled">
                  <li ><a href="database.php"> <i class="icon-home"></i>Home </a></li>
                  <li class="active"><a href="viewadmin1.php"> <i class="icon-grid"></i>View Admin </a></li>
                  <li ><a href="view_result1.php"> <i class="icon-grid"></i>View Result </a></li>

                  
                  
                </nav>
                <div class="content-inner">
                  <!-- Page Header-->
                  <header class="page-header">
                    <div class="container-fluid">
                      <h2 class="no-margin-bottom">Enterprise Admin</h2>
                    </div>
                  </header>
                  <!-- Forms Section-->
                  <section class="forms"> 
                    <div class="container-fluid">
                      <div class="row">

                        <!-- Inline Form-->
                        <div class="col-lg-12">                           
                          <div class="card">
                            <div class="card-close">
                              <div class="dropdown">
                                <button type="button" id="closeCard3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                                <div aria-labelledby="closeCard3" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a><a href="#" class="dropdown-item edit"> <i class="fa fa-gear"></i>Edit</a></div>
                              </div>
                            </div>
                            <div class="card-header d-flex align-items-center">
                              <h3 class="h4">Add Organization</h3>
                            </div>
                            <div class="card-body">
                              <form class="form-inline" method="post" action="viewadmin1.php">
                                <div class="form-group">
                                  <label for="inlineFormInput" class="sr-only">Organization</label>
                                  <input id="inlineFormInput" type="text" placeholder="Add Organization" class="mr-3 form-control" name="organization">
                                </div>

                                <div class="form-group">
                                  <button type="submit" class="btn btn-primary" name="Create_organization">Submit</button>
                                </div>
                                <?php echo display_error(); ?>
                              </form>
                            </div>
                          </div>
                        </div>
                        <!-- Basic Form-->
                        <div class="col-lg-4">
                          <div class="card">
                            <div class="card-close">
                              <div class="dropdown">
                                <button type="button" id="closeCard1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                                <div aria-labelledby="closeCard1" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a><a href="#" class="dropdown-item edit"> <i class="fa fa-gear"></i>Edit</a></div>
                              </div>
                            </div>
                            <div class="card-header d-flex align-items-center">
                              <h3 class="h4">Register Enterprise Admin</h3>
                            </div>
                            <div class="card-body">

                              <form method="post" action="viewadmin1.php">
                               <div class="form-group">
                                <label class="form-control-label">User type</label>
                                <input type="text" name="user_type" id="user_type" value="admin" readonly class="form-control">
                              </div>
                              <div class="form-group">
                                <label class="form-control-label">Username</label>
                                <input type="text" name="username" value="<?php echo $username; ?>" class="form-control">
                              </div>
                              <div class="form-group">       
                                <label class="form-control-label">Organization</label>
                                <select  name="organization" value="" class="form-control">
                                  <?php
                                  $sql = "SELECT organization FROM organization";
                                  $result = $db->query($sql);

                                  while($row = $result->fetch_assoc()) {

                                    ?>
                                    <option value="<?php echo $row["organization"];?>"> <?php echo $row["organization"];?>  </option>



                                    <?php
                                  }
                                  ?>
                                </select> 
                              </div>
                              <div class="form-group">
                                <label class="form-control-label">Email</label>
                                <input type="text" name="email" value="<?php echo $email; ?>" class="form-control">
                              </div>

                              <div class="form-group">
                                <label class="form-control-label">Password</label>
                                <input type="password" name="password_1" class="form-control">
                              </div>
                              <div class="form-group">
                                <label class="form-control-label">Confirm Password</label>
                                <input type="password" name="password_2" class="form-control">
                              </div>
                              <div class="form-group">       
                                <input type="submit" value="+ Create admin" class="btn btn-primary" name="register_btn">
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>

                      <div class="col-lg-8">
                        <div class="card">

                          <div class="card-header d-flex align-items-center">
                            <h3 class="h4">View Enterprise Admin</h3>
                          </div>
                          <div class="card-body">
                            <div class="table-responsive">                       
                              <table class="table table-striped table-hover">
                                <thead>
                                  <tr>

                                    <th>user id</th>
                                    <th>Username</th>


                                    <th>email </th>
                                    <th>user type </th>
                                    <th>organization</th>

                                    <th>delete</th>




                                  </tr>
                                </thead>
                                <tbody>

                                  <?php

                                  $sql = "SELECT *FROM users
                                  WHERE user_type='admin'";

                                  $result = $db->query($sql);

                                  while($row = $result->fetch_assoc()) {
                                    $id= $row["id"];
                                    ?>
                                    <tr>
                                      <td> <?php echo $row["id"]; ?></td>
                                      <td> <?php echo $row["username"]; ?></td>
                                      <td><?php echo $row["email"]; ?></td>
                                      <td><?php echo $row["user_type"]; ?></td>
                                      <td><?php echo $row["organization"]; ?></td>



                                      <td><a href="deleteadmin.php?del_admin=<?php echo $id?>">delete</a></td>
                                    </tr>
                                    <?php
                                  } 
                                  ?>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>





                    </div>
                  </div>
                </section>
                <!-- Page Footer-->
                <footer class="main-footer">
                  <div class="container-fluid">
                    <div class="row">
                      <div class="col-sm-6">
                        <p>Jholey Ranking &copy; 2020</p>
                      </div>

                    </div>
                  </div>
                </footer>
              </div>
            </div>
          </div>
          <!-- JavaScript files-->
          <script src="vendor/jquery/jquery.min.js"></script>
          <script src="vendor/popper.js/umd/popper.min.js"> </script>
          <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
          <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
          <script src="vendor/chart.js/Chart.min.js"></script>
          <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
          <script src="js/charts-home.js"></script>
          <!-- Main File-->
          <script src="js/front.js"></script>
        </body>
        </html>