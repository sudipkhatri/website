-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2020 at 07:27 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `multi_login`
--

-- --------------------------------------------------------

--
-- Table structure for table `commerce`
--

CREATE TABLE `commerce` (
  `id` int(11) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `ielts_score` decimal(10,0) DEFAULT NULL,
  `gpa_score` decimal(10,0) DEFAULT NULL,
  `journal` int(10) DEFAULT NULL,
  `total_percentage` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int(11) NOT NULL,
  `department` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `department`) VALUES
(35, 'science');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `management`
--

CREATE TABLE `management` (
  `id` int(11) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `ielts_score` decimal(10,0) DEFAULT NULL,
  `gpa_score` decimal(10,0) DEFAULT NULL,
  `journal` int(10) DEFAULT NULL,
  `total_percentage` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE `organization` (
  `organization_id` int(10) NOT NULL,
  `organization` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`organization_id`, `organization`) VALUES
(1, 'organization1'),
(3, 'organization2'),
(4, 'organization3');

-- --------------------------------------------------------

--
-- Table structure for table `pritam`
--

CREATE TABLE `pritam` (
  `id` int(11) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `ielts_score` decimal(10,0) DEFAULT NULL,
  `gpa_score` decimal(10,0) DEFAULT NULL,
  `journal` int(10) DEFAULT NULL,
  `total_percentage` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `result_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `department` varchar(100) NOT NULL,
  `ielts_score` varchar(100) NOT NULL,
  `ielts_size` int(255) NOT NULL,
  `gpa_score` varchar(100) NOT NULL,
  `gpa_size` int(255) NOT NULL,
  `journal` varchar(100) NOT NULL,
  `IELTS` varchar(100) NOT NULL,
  `GPA` varchar(100) NOT NULL,
  `organization` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`result_id`, `user_id`, `department`, `ielts_score`, `ielts_size`, `gpa_score`, `gpa_size`, `journal`, `IELTS`, `GPA`, `organization`) VALUES
(52, 49, 'science', '7.4', 109250, '3.3', 335533, '3', 'image.jpg', 'image2.jpg', 'organization1');

-- --------------------------------------------------------

--
-- Table structure for table `science`
--

CREATE TABLE `science` (
  `id` int(11) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `ielts_score` decimal(10,0) DEFAULT NULL,
  `gpa_score` decimal(10,0) DEFAULT NULL,
  `journal` int(10) DEFAULT NULL,
  `total_percentage` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `science`
--

INSERT INTO `science` (`id`, `user_id`, `username`, `department`, `ielts_score`, `gpa_score`, `journal`, `total_percentage`) VALUES
(1, 49, 'studentscience', 'science', '8', '3', 3, '86');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `organization` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `department`, `email`, `user_type`, `password`, `organization`) VALUES
(46, 'sudipkhatri', '', 'sudpkhatri4@gmail.com', 'mainadmin', 'd57587b0f5bbb0c3fe9d8cb16e97b0fe', ''),
(48, 'studentmanagement', '', 'studentmanagement@gmail.com', 'user', 'd57587b0f5bbb0c3fe9d8cb16e97b0fe', ''),
(49, 'studentscience', '', 'studentscience@gmail.com', 'user', 'd57587b0f5bbb0c3fe9d8cb16e97b0fe', ''),
(50, 'studentcommerce', '', 'studentcommerce@gmail.com', 'user', 'd57587b0f5bbb0c3fe9d8cb16e97b0fe', ''),
(51, 'enterpriseadmin', '', 'enterpriseadmin@gmai.com', 'admin', 'd57587b0f5bbb0c3fe9d8cb16e97b0fe', 'organization1'),
(52, 'adminscience', 'science', 'adminscience@gmail.com', 'departmentadmin', 'd57587b0f5bbb0c3fe9d8cb16e97b0fe', ''),
(54, 'adminmanagement', 'management', 'adminmanagement@gmail.com', 'departmentadmin', 'd57587b0f5bbb0c3fe9d8cb16e97b0fe', ''),
(55, 'admincommerce', 'commerce', 'admincommerce@gmail.com', 'departmentadmin', 'd57587b0f5bbb0c3fe9d8cb16e97b0fe', ''),
(59, 'admins', 'science', 'admins@gmail.com', 'departmentadmin', 'd57587b0f5bbb0c3fe9d8cb16e97b0fe', ''),
(60, 'adminc', 'commerce', 'adminc@gmail.com', 'departmentadmin', 'd57587b0f5bbb0c3fe9d8cb16e97b0fe', ''),
(61, 'adminm', 'management', 'adminm@gmail.com', 'departmentadmin', 'd57587b0f5bbb0c3fe9d8cb16e97b0fe', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `commerce`
--
ALTER TABLE `commerce`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `management`
--
ALTER TABLE `management`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organization`
--
ALTER TABLE `organization`
  ADD PRIMARY KEY (`organization_id`);

--
-- Indexes for table `pritam`
--
ALTER TABLE `pritam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`result_id`);

--
-- Indexes for table `science`
--
ALTER TABLE `science`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `commerce`
--
ALTER TABLE `commerce`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `management`
--
ALTER TABLE `management`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `organization`
--
ALTER TABLE `organization`
  MODIFY `organization_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pritam`
--
ALTER TABLE `pritam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `result_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `science`
--
ALTER TABLE `science`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
