<?php 


include('futction_result.php');


if (!isLoggedIn()) {
  $_SESSION['msg'] = "You must log in first";


  header('location: register.php');
}


?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin Dashboard</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="robots" content="all,follow">
  <!-- Bootstrap CSS-->
  <link rel="stylesheet" href="distribution/vendor/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome CSS-->
  <link rel="stylesheet" href="distribution/vendor/font-awesome/css/font-awesome.min.css">
  <!-- Fontastic Custom icon font-->
  <link rel="stylesheet" href="distribution/css/fontastic.css">
  <!-- Google fonts - Poppins -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
  <!-- theme stylesheet-->
  <link rel="stylesheet" href="distribution/css/style.default.css" id="theme-stylesheet">
  <!-- Custom stylesheet - for your changes-->
  <link rel="stylesheet" href="distribution/css/custom.css">
  <!-- Favicon-->
  <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
      </head>
      <body>
        <div class="page">
          <!-- Main Navbar-->
          <header class="header">
            <nav class="navbar">
              <!-- Search Box-->
              <div class="search-box">
                <button class="dismiss"><i class="icon-close"></i></button>

              </div>
              <div class="container-fluid">
                <div class="navbar-holder d-flex align-items-center justify-content-between">
                  <!-- Navbar Header-->
                  <div class="navbar-header">
                    <!-- Navbar Brand --><a href="database.html" class="navbar-brand d-none d-sm-inline-block">
                      <div class="brand-text d-none d-lg-inline-block"><span>Student </span><strong>Dashboard</strong></div>
                      <div class="brand-text d-none d-sm-inline-block d-lg-none"><strong>AD</strong></div></a>
                      <!-- Toggle Button--><a id="toggle-btn" href="#" class="menu-btn active"><span></span><span></span><span></span></a>
                    </div>
                    <!-- Navbar Menu -->
                    <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">


                      <!-- Logout    -->
                      <li class="nav-item"><a href="database.php?logout='1'" class="nav-link logout"> <span class="d-none d-sm-inline">Logout</span><i class="fa fa-sign-out"></i></a></li>
                    </ul>
                  </div>
                </div>
              </nav>
            </header>
            <div class="page-content d-flex align-items-stretch"> 
              <!-- Side Navbar -->
              <nav class="side-navbar">
                <!-- Sidebar Header-->
                <div class="sidebar-header d-flex align-items-center">
                  <div class="avatar"><img src="distribution/img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
                  <div class="title">
                    <h1 class="h4"><?php $name=$_SESSION['username'];echo "$name";?></h1>
                    
                  </div>
                </div>
                <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
                <ul class="list-unstyled">
                  <li class="active"><a href="student1.php"> <i class="icon-home"></i>Home </a></li>
                  
                  
                  
                </nav>
                <div class="content-inner">
                  <!-- Page Header-->
                  <header class="page-header">
                    <div class="container-fluid">
                      <h2 class="no-margin-bottom">Student Scholarship Form</h2>
                    </div>
                  </header>
                  <!-- Forms Section-->
                  <section class="forms"> 
                    <div class="container-fluid">
                      <div class="row">


                        <!-- Basic Form-->
                        <div class="col-lg-4">
                          <div class="card">
                            <div class="card-close">
                              <div class="dropdown">
                                <button type="button" id="closeCard1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                                <div aria-labelledby="closeCard1" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a><a href="#" class="dropdown-item edit"> <i class="fa fa-gear"></i>Edit</a></div>
                              </div>
                            </div>
                            <div class="card-header d-flex align-items-center">
                              <h3 class="h4">Apply For Scholarship</h3>
                            </div>
                            <div class="card-body">

                              <form method="post" action="database.php">
                               <div class="form-group">
                                <label class="form-control-label">Select Organization</label>
                                <select type="text" name="organization" value="" class="form-control">
                                  <?php
                                  $sql = "SELECT organization FROM organization";
                                  $result = $db1->query($sql);

                                  while($row = $result->fetch_assoc()) {


                                    ?>
                                    <option value=" <?php echo $row["organization"];?>"> <?php echo $row["organization"];?>  </option>



                                    <?php
                                  }
                                  ?>
                                </select>
                              </div>
                              
                              <div class="form-group">       
                                <label class="form-control-label">Department</label>
                                <select  name="department" value="" class="form-control">
                                  <?php
                                  $sql = "SELECT department FROM department";
                                  $result = $db1->query($sql);

                                  while($row = $result->fetch_assoc()) {

                                    ?>
                                    <option value="<?php echo $row["department"];?>"> <?php echo $row["department"];?>  </option>



                                    <?php
                                  }
                                  ?>
                                </select> 
                              </div>
                              <div class="form-group">
                                <label class="form-control-label">IELTS score</label>
                                <input type="text" name="ielts_score" value="" class="form-control">
                              </div>
                              <div class="form-group">
                                <label class="form-control-label">GPA score</label>
                                <input type="text" name="gpa_score" value="" class="form-control">
                              </div>
                              <div class="form-group">
                                <label class="form-control-label">Number of journal</label>

                                <select name="journal" value="" class="form-control">
                                  <option>1</option>
                                  <option>2</option>
                                  <option>3</option>
                                </select>
                              </div>
                              <div class="form-group">
                                <label class="form-control-label">IELTS</label>
                                <input type="file"  name="ielts" class="form-control">
                              </div>
                              <div class="form-group">
                                <label class="form-control-label">GPA </label>
                                <input type="file"  name="gpa" class="form-control">
                              </div>




                              <div class="form-group">
                                <button type="submit" class="btn btn-primary" name="apply">Apply</button>
                              </div>
                              
                            </form>
                          </div>
                        </div>
                      </div>


                      <div class="col-lg-8">
                        <div class="card">

                          <div class="card-header d-flex align-items-center">
                            <h3 class="h4">View Result</h3>
                          </div>


                          <div class="card-body">
                            <div class="table-responsive">                       
                              <table class="table table-striped table-hover">
                                <thead>
                                  <tr>

                                   <th>User ID</th>
                                   <th>Username</th>
                                   <th>department</th>
                                   <th>ielts </th>
                                   <th>gpa </th>
                                   <th>journal </th>
                                   <th>total percentage</th>


                                 </tr>
                               </thead>
                               <tbody>


                                <?php
                                $name=$_SESSION['username'];
                                $user_id="";

                                $sql = "SELECT result.department FROM result 
                                INNER JOIN users ON result.user_id=users.id

                                WHERE users.username='$name'";
                                $result = $db1->query($sql);
                                while($row = $result->fetch_assoc()) {

                                  $user_id=$row["department"];
                                  $sql1 = "SELECT * FROM $user_id";
                                  $result1 = $db1->query($sql1);
                                  if ($result1->num_rows > 0) {
                                    while($row1 = $result1->fetch_assoc()) {
                                      ?>
                                      <tr>
                                       <td> <?php echo $row1["id"]; ?></td>
                                       <td> <?php echo $row1["username"]; ?></td>


                                       <td><?php echo $row1["department"]; ?></td>
                                       <td><?php echo $row1["ielts_score"]; ?></td>
                                       <td><?php echo $row1["gpa_score"]; ?></td>
                                       <td><?php echo $row1["journal"]; ?></td>

                                       <td><?php echo $row1["total_percentage"]; ?></td>
                                     </tr>

                                     <?php
                                   }
                                 
                                    $sql2="SELECT total_percentage FROM $user_id WHERE username='$name'";
                                   
                                    $result2 = $db1->query($sql2);
                                    if ($result2->num_rows > 0) {
                                      while($row2 = $result2->fetch_assoc()) {

                                        $marks=$row2["total_percentage"];
                                        
                                        if ($marks>=90) {
                                          echo "you have been granted full scholoarship";
                                         
                                        }
                                        elseif ($marks>=80) {
                                          echo "you have been granted half scholoarship";
                                        }
                                        elseif ($marks>=70) {
                                          echo "you have been granted 25% scholoarship";
                                        }
                                        elseif ($marks>=60) {
                                          echo "you have been granted 10% scholoarship";
                                        }
                                         else {
                                          echo "Sorry you are not given scholarship";
                                        }
                                      }

                                    }

                                 }else{

                                  ?>
                                  <h3><?php
                                  echo 'the result is not published ';?></h3>

                                  
                                  <?php
                                }

                              }

                              ?>


                            </tbody>
                          </table>

                        </div>
                      </div>
                    </div>
                  </div>






                </div>
              </div>
            </section>
            <!-- Page Footer-->
            <footer class="main-footer">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-sm-6">
                    <p>Jholey Ranking &copy; 2020</p>
                  </div>

                </div>
              </div>
            </footer>
          </div>
        </div>
      </div>
      <!-- JavaScript files-->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/popper.js/umd/popper.min.js"> </script>
      <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
      <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
      <script src="vendor/chart.js/Chart.min.js"></script>
      <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
      <script src="js/charts-home.js"></script>
      <!-- Main File-->
      <script src="js/front.js"></script>
    </body>
    </html>