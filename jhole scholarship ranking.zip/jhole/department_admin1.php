<?php 
include('function.php');

if (!isLoggedIn()) {
  $_SESSION['msg'] = "You must log in first";
  header('location: register.php');
}

if (isset($_GET['logout'])) {
  session_destroy();
  unset($_SESSION['user']);
  header("location: index.php");
}


?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin Dashboard</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="robots" content="all,follow">
  <!-- Bootstrap CSS-->
  <link rel="stylesheet" href="distribution/vendor/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome CSS-->
  <link rel="stylesheet" href="distribution/vendor/font-awesome/css/font-awesome.min.css">
  <!-- Fontastic Custom icon font-->
  <link rel="stylesheet" href="distribution/css/fontastic.css">
  <!-- Google fonts - Poppins -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
  <!-- theme stylesheet-->
  <link rel="stylesheet" href="distribution/css/style.default.css" id="theme-stylesheet">
  <!-- Custom stylesheet - for your changes-->
  <link rel="stylesheet" href="distribution/css/custom.css">
  <!-- Favicon-->
  <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
      </head>
      <body>
        <div class="page">
          <!-- Main Navbar-->
          <header class="header">
            <nav class="navbar">
              <!-- Search Box-->
              <div class="search-box">
                <button class="dismiss"><i class="icon-close"></i></button>

              </div>
              <div class="container-fluid">
                <div class="navbar-holder d-flex align-items-center justify-content-between">
                  <!-- Navbar Header-->
                  <div class="navbar-header">
                    <!-- Navbar Brand --><a href="database.php" class="navbar-brand d-none d-sm-inline-block">
                      <div class="brand-text d-none d-lg-inline-block"><span>Admin </span><strong>Dashboard</strong></div>
                      <div class="brand-text d-none d-sm-inline-block d-lg-none"><strong>AD</strong></div></a>
                      <!-- Toggle Button--><a id="toggle-btn" href="#" class="menu-btn active"><span></span><span></span><span></span></a>
                    </div>
                    <!-- Navbar Menu -->
                    <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">


                      <!-- Logout    -->
                      <li class="nav-item"><a href="database.php?logout='1'" class="nav-link logout"> <span class="d-none d-sm-inline">Logout</span><i class="fa fa-sign-out"></i></a></li>
                    </ul>
                  </div>
                </div>
              </nav>
            </header>
            <div class="page-content d-flex align-items-stretch"> 
              <!-- Side Navbar -->
              <nav class="side-navbar">
                <!-- Sidebar Header-->
                <div class="sidebar-header d-flex align-items-center">
                  <div class="avatar"><img src="distribution/img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
                  <div class="title">
                    <h1 class="h4"><?php $name=$_SESSION['username'];echo "$name";?></h1>
                    
                  </div>
                </div>
                <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
                <ul class="list-unstyled">
                  <li  class="active"><a href="department_admin1.php"> <i class="icon-home"></i>Home </a></li>
                  
                  
                  
                </nav>
                <div class="content-inner">
                  <!-- Page Header-->
                  <header class="page-header">
                    <div class="container-fluid">
                      <h2 class="no-margin-bottom">Dashboard</h2>
                    </div>
                  </header>
                  <!-- Inline Form-->
                  <div class="col-lg-6">                           
                    <div class="card">
                      <div class="card-close">

                      </div>
                      <div class="card-header d-flex align-items-center">
                        <h3 class="h4">Add Department</h3>
                      </div>
                      <div class="card-body">
                        <form method="post" action="department_admin1.php">

                          <div class="form-group">

                           <label for="inlineFormInput" >please select to calculate marks</label>
                           <select name="ielts_percent" class="form-control">

                            <option>ielts percent</option> 
                            <option value="0.1">10</option>
                            <option value="0.2">20</option>
                            <option value="0.3">30</option>
                            <option value="0.4">40</option>
                            <option value="0.5">50</option>
                            <option value="0.6">60</option>
                            <option value="0.7">70</option>
                            <option value="0.8">80</option>
                            <option value="0.9">90</option>
                            <option value="1">100</option>
                            <option value="0.0">0</option>
                          </select>&nbsp;
                          <select name="gpa_percent" class="form-control">

                            <option>gpa percent</option> 
                            <option value="0.1">10</option>
                            <option value="0.2">20</option>
                            <option value="0.3">30</option>
                            <option value="0.4">40</option>
                            <option value="0.5">50</option>
                            <option value="0.6">60</option>
                            <option value="0.7">70</option>
                            <option value="0.8">80</option>
                            <option value="0.9">90</option>
                            <option value="1">100</option>
                            <option value="0.0">0</option>
                          </select>&nbsp;
                          <select name="journal_percent" class="form-control">

                            <option>journal percent</option> 
                            <option value="0.1">10</option>
                            <option value="0.2">20</option>
                            <option value="0.3">30</option>
                            <option value="0.4">40</option>
                            <option value="0.5">50</option>
                            <option value="0.6">60</option>
                            <option value="0.7">70</option>
                            <option value="0.8">80</option>
                            <option value="0.9">90</option>
                            <option value="1">100</option>
                            <option value="0.0">0</option>
                          </select>&nbsp;


                        </div>

                        <div class="form-group">

                         <button type="submit" class="btn btn-primary" name="submit_1"> View result </button> &nbsp;
                       </div>

                     </form>
                   </div>
                 </div>
               </div>
               <?php

               if (isset($_POST['submit_1'])) {
                $name=$_SESSION['username'];

                $user_id="";

                $sql = "SELECT department FROM users


                WHERE username='$name'";
                $result = $db->query($sql);
                while($row = $result->fetch_assoc()) {
                 $user_id=$row["department"];


                 ?>


                 <div class="col-lg-12">
                  <div class="card">

                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">View Result</h3>
                    </div>


                    <div class="card-body">
                      <div class="table-responsive">                       
                        <table class="table table-striped table-hover">
                          <thead>
                            <tr>

                              <th>Username</th>
                              <th>department</th>
                              <th>ielts </th>
                              <th>gpa </th>
                              <th>journal </th>
                              <th>total </th>
                              <th>update</th>
                              <th>delete</th>



                            </tr>
                          </thead>
                          <tbody>



                            <?php
                            $ielts_percent=$_POST['ielts_percent'];
                            $gpa_percent=$_POST['gpa_percent'];
                            $journal_percent=$_POST['journal_percent'];
                            $sql = "SELECT users.id,users.username, users.id,result.department,result.ielts_score,result.gpa_score,result.journal,
                            ROUND(((result.gpa_score*100)/4)*$gpa_percent+ ((result.ielts_score*100)/9)*$ielts_percent+((result.journal*100)/3)*$journal_percent,2) AS total_percentage
                            FROM result

                            INNER JOIN users ON result.user_id=users.id
                            WHERE result.department='$user_id'
                            ORDER BY total_percentage desc";
                            ?>

                            <?php
                            $result = $db->query($sql);

                            while($row = $result->fetch_assoc()) {
                              $id= $row["id"];

                              



                              
                              
                              ?>
                              <tr>
                                <td> <?php echo $row["username"]; ?></td>


                                <td><?php echo $row["department"]; ?></td>
                                <td><?php echo $row["ielts_score"]; ?></td>
                                <td><?php echo $row["gpa_score"]; ?></td>
                                <td><?php echo $row["journal"]; ?></td>

                                <td><?php echo $row["total_percentage"]; ?></td>
                                <td><a href="department_update.php?GETID=<?php echo $id?>">update</a></td>
                                <td><a href="department_delete.php?del=<?php echo $id?>">delete</a></td>
                              </tr>
                              <?php
                            }


                          }

                        }




                        ?>



                      </tbody>
                    </table>

                  </div>
                </div>
              </div>
            </div>

            <!-- Page Footer-->
            <footer class="main-footer">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-sm-6">
                    <p>Jholey Ranking &copy; 2020</p>
                  </div>

                </div>
              </div>
            </footer>
          </div>
        </div>
      </div>
      <!-- JavaScript files-->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/popper.js/umd/popper.min.js"> </script>
      <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
      <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
      <script src="vendor/chart.js/Chart.min.js"></script>
      <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
      <script src="js/charts-home.js"></script>
      <!-- Main File-->
      <script src="js/front.js"></script>
    </body>
    </html>