<?php 
session_start();

// connect to database
$db1 = mysqli_connect('localhost', 'root', '', 'multi_login');

// variable declaration

$errors   = array(); 
$department   = "";
$ielts_score   ="";
$gpa_score  ="";
$journal="";
if ($db1->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
else{
	
}
if (isset($_POST['apply'])) {
	apply();

}

// REGISTER USER
function apply(){
	// call these variables with the global keyword to make them available in function
	global $db1,$department,$ielts_score,$gpa_score,$journal,$errors;
	// receive all input values from the form. Call the e() function
    // defined below to escape form values
	
	$organization   =  e($_POST['organization']);
	$department   =  e($_POST['department']);
	$ielts_score   = e($_POST['ielts_score']);
	$gpa_score  =  e($_POST['gpa_score']);
	$journal=	e($_POST['journal']);
	 
	
	$filename=$_FILES['ielts']['name'];
	$destination='uploads_ielts/'.$filename;
	$extension=pathinfo($filename,PATHINFO_EXTENSION);
	$file=$_FILES['ielts']['tmp_name'];
	$size=$_FILES['ielts']['size'];
	if (move_uploaded_file($file, $destination)) {

    		$ielts  = $filename;
    		$ielts_size=$size;
    	}
    	$filename=$_FILES['gpa']['name'];
	$destination='upload_gpa/'.$filename;
	$extension=pathinfo($filename,PATHINFO_EXTENSION);
	$file=$_FILES['gpa']['tmp_name'];
	$size=$_FILES['gpa']['size'];
	if (move_uploaded_file($file, $destination)) {

    		$gpa= $filename;
    		$gpa_size=$size;
    	}



    $name=$_SESSION['username'];
    $sql = "SELECT id FROM users WHERE username='$name'";
    $result = $db1->query($sql);

    if ($result->num_rows > 0) {
  // output data of each row
    	while($row = $result->fetch_assoc()) {

    		$user_id=$row["id"];

    	}
    } else {
    	echo "0 results";
    }
    $sql1=	"SELECT user_id FROM result WHERE user_id='$user_id'";
    $result1 = $db1->query($sql1);

    if ($result1->num_rows > 0) {
  // output data of each row
    	echo '<script type="text/javascript">';
        echo ' alert("You have already applied for scholarship")';  //not showing an alert box.
        echo '</script>';

    } else {
  // form validation: ensure that the form is correctly filled
    	if (empty($department)) { 
    		array_push($errors, "department is required"); 
    	}
    	if (empty($ielts_score)) { 
    		array_push($errors, "ielts_score is required"); 
    	}
    	if (empty($gpa_score)) { 
    		array_push($errors, "gpa_score  is required"); 
    	}

    	$query = "INSERT INTO result (user_id,department,ielts_score,ielts_size,gpa_score,gpa_size,journal,IELTS,GPA,organization) 
    	VALUES('$user_id','$department','$ielts_score','$ielts_size','$gpa_score','$gpa_size','$journal','$ielts','$gpa','$organization')";
    	mysqli_query($db1, $query);
    	$_SESSION['success']  = "You have successfully applied";
    	$_SESSION['success']  = "New user successfully created!!";



    }



	// register user if there are no errors in the form







}
function isLoggedIn()
{
	if (isset($_SESSION['user'])) {
		return true;
	}else{
		return false;
	}
}
if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['user']);
	header("location: index.php");
}


function e($val){
	global $db1;
	return mysqli_real_escape_string($db1, trim($val));
}